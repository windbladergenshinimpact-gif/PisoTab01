PisoTab Remote Lock API
=======================

The APK polls an HTTPS endpoint and expects JSON:

  {"locked": true, "message": "Client disabled by admin"}

or:

  {"locked": false, "message": "Client enabled"}

The client sends the client ID in the query string (unless {clientId} is used in the configured URL) and in the X-PisoTab-Client-Id header.

For production, put the API behind HTTPS and authentication. Do not expose an unauthenticated lock/unlock endpoint on the public internet.

server.py is only a local protocol example; it is not a production admin server.
