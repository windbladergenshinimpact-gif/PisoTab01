package com.example.pisotab

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.CountDownTimer
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var txtTime: TextView
    private lateinit var txtCoins: TextView
    private lateinit var txtBluetooth: TextView

    private var coins = 0
    private var secondsLeft = 0L
    private var timer: CountDownTimer? = null
    private var bluetoothSocket: BluetoothSocket? = null
    private var bluetoothThread: Thread? = null

    private val prefs by lazy { getSharedPreferences("pisotab_settings", MODE_PRIVATE) }

    private var minutesPerPeso: Int
        get() = prefs.getInt("minutes_per_peso", 10)
        set(value) = prefs.edit().putInt("minutes_per_peso", value).apply()

    private var adminPassword: String
        get() = prefs.getString("admin_password", "1234") ?: "1234"
        set(value) = prefs.edit().putString("admin_password", value).apply()

    private val bluetoothAdapter: BluetoothAdapter?
        get() = BluetoothAdapter.getDefaultAdapter()

    companion object {
        private const val REQUEST_BLUETOOTH = 1001
        private val SPP_UUID: UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtTime = findViewById(R.id.txtTime)
        txtCoins = findViewById(R.id.txtCoins)
        txtBluetooth = findViewById(R.id.txtBluetooth)

        findViewById<Button>(R.id.btnTestCoin).setOnClickListener { addCoin() }
        findViewById<Button>(R.id.btnBluetooth).setOnClickListener { connectEsp32() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showPasswordDialog() }

        updateScreen()
    }

    private fun hasBluetoothConnectPermission(): Boolean {
        return android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.S ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun connectEsp32() {
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "This tablet has no Bluetooth", Toast.LENGTH_LONG).show()
            return
        }

        if (!hasBluetoothConnectPermission()) {
            requestPermissions(
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                REQUEST_BLUETOOTH
            )
            return
        }

        if (bluetoothAdapter?.isEnabled != true) {
            Toast.makeText(this, "Turn on Bluetooth first", Toast.LENGTH_LONG).show()
            startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
            return
        }

        val devices = try {
            bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
        } catch (_: SecurityException) {
            emptyList()
        }

        if (devices.isEmpty()) {
            Toast.makeText(
                this,
                "Pair the ESP32 in Android Bluetooth settings first.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
            return
        }

        val names = devices.map { device ->
            try {
                "${device.name ?: "Unknown"}\n${device.address}"
            } catch (_: SecurityException) {
                "Bluetooth device"
            }
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Select ESP32")
            .setItems(names) { _, which -> connectToDevice(devices[which]) }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun connectToDevice(device: BluetoothDevice) {
        if (!hasBluetoothConnectPermission()) return

        disconnectBluetooth()
        txtBluetooth.text = "Bluetooth: Connecting..."

        bluetoothThread = Thread {
            try {
                val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                bluetoothSocket = socket
                socket.connect()

                runOnUiThread {
                    txtBluetooth.text = "Bluetooth: Connected"
                    Toast.makeText(this, "ESP32 connected", Toast.LENGTH_SHORT).show()
                }

                val reader = BufferedReader(InputStreamReader(socket.inputStream))

                while (!Thread.currentThread().isInterrupted) {
                    val line = reader.readLine() ?: break
                    val command = line.trim().uppercase()

                    if (command == "COIN1" || command == "COIN" || command == "1") {
                        runOnUiThread { addCoin() }
                    }
                }
            } catch (_: Exception) {
                runOnUiThread {
                    txtBluetooth.text = "Bluetooth: Disconnected"
                    Toast.makeText(
                        this,
                        "ESP32 connection failed/disconnected",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }.also { it.start() }
    }

    private fun disconnectBluetooth() {
        try { bluetoothThread?.interrupt() } catch (_: Exception) {}
        try { bluetoothSocket?.close() } catch (_: Exception) {}
        bluetoothSocket = null
        bluetoothThread = null
    }

    private fun addCoin() {
        coins++
        secondsLeft += minutesPerPeso * 60L
        txtCoins.text = "Coins: $coins"
        startTimer()
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(secondsLeft * 1000L, 1000L) {
            override fun onTick(ms: Long) {
                secondsLeft = ms / 1000L
                updateScreen()
            }

            override fun onFinish() {
                secondsLeft = 0
                updateScreen()
                Toast.makeText(this@MainActivity, "TIME EXPIRED", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun updateScreen() {
        val h = secondsLeft / 3600
        val m = (secondsLeft % 3600) / 60
        val s = secondsLeft % 60
        txtTime.text = String.format("%02d:%02d:%02d", h, m, s)
        txtCoins.text = "Coins: $coins"
    }

    private fun showPasswordDialog() {
        val input = EditText(this).apply {
            hint = "Admin password"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 8, 48, 0)
            addView(input)
        }

        AlertDialog.Builder(this)
            .setTitle("Admin Settings")
            .setMessage("Enter password")
            .setView(box)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("OK") { _, _ ->
                if (input.text.toString() == adminPassword) {
                    showSettingsDialog()
                } else {
                    Toast.makeText(this, "Wrong password", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showSettingsDialog() {
        val minutesInput = EditText(this).apply {
            hint = "Minutes per ₱1"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(minutesPerPeso.toString())
        }

        val passwordInput = EditText(this).apply {
            hint = "New admin password"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setText(adminPassword)
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 8, 48, 0)
            addView(minutesInput)
            addView(passwordInput)
        }

        AlertDialog.Builder(this)
            .setTitle("PisoTab Settings")
            .setMessage("Change the ₱1 time and admin password.")
            .setView(box)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("SAVE") { _, _ ->
                val newMinutes = minutesInput.text.toString().toIntOrNull()
                val newPassword = passwordInput.text.toString()

                if (newMinutes == null || newMinutes <= 0) {
                    Toast.makeText(this, "Minutes must be greater than 0", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (newPassword.isBlank()) {
                    Toast.makeText(this, "Password cannot be empty", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                minutesPerPeso = newMinutes
                adminPassword = newPassword

                Toast.makeText(
                    this,
                    "Saved: ₱1 = $newMinutes minutes",
                    Toast.LENGTH_LONG
                ).show()
            }
            .show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_BLUETOOTH &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            connectEsp32()
        } else if (requestCode == REQUEST_BLUETOOTH) {
            Toast.makeText(
                this,
                "Bluetooth permission is required to connect ESP32",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onDestroy() {
        timer?.cancel()
        disconnectBluetooth()
        super.onDestroy()
    }
}
