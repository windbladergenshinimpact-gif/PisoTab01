package com.example.pisotab

import android.app.admin.DeviceAdminReceiver

class PisoTabDeviceAdminReceiver : DeviceAdminReceiver()
