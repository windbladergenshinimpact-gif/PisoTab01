plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.pisotab"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.pisotab"
        minSdk = 23
        targetSdk = 35
        versionCode = 7
        versionName = "1.7"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
