package com.example.pisotab

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.app.AlertDialog
import android.app.DownloadManager
import android.app.role.RoleManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebStorage
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var txtTime: TextView
    private lateinit var txtCoins: TextView
    private lateinit var txtEsp32: TextView
    private lateinit var txtRate: TextView
    private lateinit var browserPanel: LinearLayout
    private lateinit var mainPanel: LinearLayout
    private lateinit var webView: WebView
    private lateinit var txtBrowserTime: TextView
    private lateinit var remoteLockOverlay: LinearLayout
    private lateinit var txtRemoteLockMessage: TextView
    private lateinit var txtRemoteLockClient: TextView
    private var coins = 0
    private var secondsLeft = 0L
    private var timer: CountDownTimer? = null
    private var socket: BluetoothSocket? = null

    private val prefs by lazy { getSharedPreferences("pisotab_settings", MODE_PRIVATE) }
    private var minutesPerPeso: Int
        get() = prefs.getInt("minutes_per_peso", 5)
        set(v) = prefs.edit().putInt("minutes_per_peso", v).apply()
    private var adminPassword: String
        get() = prefs.getString("admin_password", "1234") ?: "1234"
        set(v) = prefs.edit().putString("admin_password", v).apply()
    private var dialogRef: AlertDialog? = null
    private var staffPassword: String
        get() = prefs.getString("staff_password", "1234") ?: "1234"
        set(v) = prefs.edit().putString("staff_password", v).apply()
    private var kioskMode: Boolean
        get() = prefs.getBoolean("kiosk_mode", true)
        set(v) = prefs.edit().putBoolean("kiosk_mode", v).apply()
    private var defaultLauncher: Boolean
        get() = prefs.getBoolean("default_launcher", false)
        set(v) = prefs.edit().putBoolean("default_launcher", v).apply()
    private var bluetoothAlarm: Boolean
        get() = prefs.getBoolean("bt_alarm", false)
        set(v) = prefs.edit().putBoolean("bt_alarm", v).apply()
    private var chargerAlarm: Boolean
        get() = prefs.getBoolean("charger_alarm", false)
        set(v) = prefs.edit().putBoolean("charger_alarm", v).apply()
    private var whitelistMode: Boolean
        get() = prefs.getBoolean("whitelist_mode", false)
        set(v) = prefs.edit().putBoolean("whitelist_mode", v).apply()
    private val recommendedAllowedPackages = setOf(
        "com.android.chrome",
        "com.google.android.youtube",
        "com.google.android.apps.nbu.files",
        "com.google.android.apps.photos",
        "com.google.android.calculator"
    )
    private var allowedPackages: Set<String>
        get() = prefs.getStringSet("allowed_packages", recommendedAllowedPackages) ?: recommendedAllowedPackages
        set(v) = prefs.edit().putStringSet("allowed_packages", v).apply()
    private var btTargetName: String
        get() = prefs.getString("bt_target_name", "ESP32") ?: "ESP32"
        set(v) = prefs.edit().putString("bt_target_name", v).apply()
    private var autoClearOnExpiry: Boolean
        get() = prefs.getBoolean("auto_clear_on_expiry", true)
        set(v) = prefs.edit().putBoolean("auto_clear_on_expiry", v).apply()
    private var clientName: String
        get() = prefs.getString("client_name", "Client 01") ?: "Client 01"
        set(v) = prefs.edit().putString("client_name", v).apply()
    private var clientId: String
        get() = prefs.getString("client_id", "C001") ?: "C001"
        set(v) = prefs.edit().putString("client_id", v).apply()
    private var remoteControlEnabled: Boolean
        get() = prefs.getBoolean("remote_control_enabled", false)
        set(v) = prefs.edit().putBoolean("remote_control_enabled", v).apply()
    private var remoteControlUrl: String
        get() = prefs.getString("remote_control_url", "") ?: ""
        set(v) = prefs.edit().putString("remote_control_url", v).apply()
    private var remoteLocked: Boolean
        get() = prefs.getBoolean("remote_locked", false)
        set(v) = prefs.edit().putBoolean("remote_locked", v).apply()
    private var remoteLockMessage: String
        get() = prefs.getString("remote_lock_message", "This client is temporarily disabled by the administrator.") ?: "This client is temporarily disabled by the administrator."
        set(v) = prefs.edit().putString("remote_lock_message", v).apply()
    private var remotePollSeconds: Int
        get() = prefs.getInt("remote_poll_seconds", 15)
        set(v) = prefs.edit().putInt("remote_poll_seconds", v).apply()
    private var remoteThread: Thread? = null
    private var remoteRunning = false

    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        // Preselect common customer apps when the whitelist is used for the first time.
        if (!prefs.contains("allowed_packages")) {
            allowedPackages = recommendedAllowedPackages
        }

        txtTime = findViewById(R.id.txtTime)
        txtCoins = findViewById(R.id.txtCoins)
        txtEsp32 = findViewById(R.id.txtEsp32)
        txtRate = findViewById(R.id.txtRate)
        mainPanel = findViewById(R.id.mainPanel)
        browserPanel = findViewById(R.id.browserPanel)
        webView = findViewById(R.id.webView)
        txtBrowserTime = findViewById(R.id.txtBrowserTime)
        remoteLockOverlay = findViewById(R.id.remoteLockOverlay)
        txtRemoteLockMessage = findViewById(R.id.txtRemoteLockMessage)
        txtRemoteLockClient = findViewById(R.id.txtRemoteLockClient)

        findViewById<Button>(R.id.btnTestCoin).setOnClickListener { addCoin() }
        findViewById<Button>(R.id.btnBrowser).setOnClickListener { openBrowser() }
        findViewById<Button>(R.id.btnAllowedApps).setOnClickListener { showCustomerAppsDialog() }
        findViewById<Button>(R.id.btnConnect).setOnClickListener { connectEsp32() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showPasswordDialog() }
        findViewById<Button>(R.id.btnMainHomeLauncher).setOnClickListener { goToHomeLauncher() }
        findViewById<Button>(R.id.btnBrowserHome).setOnClickListener { webView.loadUrl("file:///android_asset/home.html") }
        findViewById<Button>(R.id.btnBrowserBack).setOnClickListener { if (webView.canGoBack()) webView.goBack() else closeBrowser() }
        findViewById<Button>(R.id.btnHomeLauncher).setOnClickListener { goToHomeLauncher() }

        setupBrowser()
        updateScreen()
        requestBtPermission()
        applyKioskMode()
        applyRemoteLockUi()
        startRemoteControl()
    }

    private fun setupBrowser() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            saveFormData = false
            setSupportMultipleWindows(false)
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            allowContentAccess = true
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val name = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType)
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .setTitle(name)
                    .setDescription("PisoTab customer download")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                    .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
                val cookies = CookieManager.getInstance().getCookie(url)
                if (!cookies.isNullOrBlank()) request.addRequestHeader("Cookie", cookies)
                request.addRequestHeader("User-Agent", userAgent)
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun openBrowser() {
        if (remoteLocked) { Toast.makeText(this, "CLIENT IS REMOTELY LOCKED", Toast.LENGTH_SHORT).show(); return }
        if (secondsLeft <= 0L) {
            Toast.makeText(this, "Insert a coin first", Toast.LENGTH_SHORT).show()
            return
        }
        mainPanel.visibility = View.GONE
        browserPanel.visibility = View.VISIBLE
        if (webView.url.isNullOrBlank() || webView.url == "about:blank") webView.loadUrl("file:///android_asset/home.html")
        applyKioskMode()
    }

    private fun requestHomeLauncherRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val roleManager = getSystemService(RoleManager::class.java)
                if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    if (!roleManager.isRoleHeld(RoleManager.ROLE_HOME)) {
                        startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME), 700)
                    } else {
                        Toast.makeText(this, "PisoTab is already the Home Launcher", Toast.LENGTH_SHORT).show()
                    }
                    return
                }
            } catch (_: Exception) { }
        }
        Toast.makeText(this, "Select PisoTab as Home app in Android Settings", Toast.LENGTH_LONG).show()
    }

    private fun goToHomeLauncher() {
        // Return to the Android Home/Launcher. If PisoTab is the default Home app,
        // Android will keep PisoTab as the Home surface (useful for kiosk mode).
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addCategory(Intent.CATEGORY_DEFAULT)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(homeIntent)
        } catch (_: Exception) {
            closeBrowser()
        }
    }

    private fun closeBrowser() {
        browserPanel.visibility = View.GONE
        mainPanel.visibility = View.VISIBLE
    }

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 22)
        }
    }

    private fun applyKioskMode() {
        if (!kioskMode) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            return
        }
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        try {
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(this, PisoTabDeviceAdminReceiver::class.java)
            if (!dpm.isDeviceOwnerApp(packageName)) return

            val permitted = (if (whitelistMode) allowedPackages else emptySet()) + packageName
            dpm.setLockTaskPackages(admin, permitted.toTypedArray())

            if (Build.VERSION.SDK_INT >= 28) {
                dpm.setLockTaskFeatures(admin, 0)
            }

            // When whitelist mode is enabled, suspend launchable packages that are not
            // explicitly allowed. This is stronger than merely hiding them from a launcher.
            if (Build.VERSION.SDK_INT >= 24 && whitelistMode) {
                val disallowed = getLaunchableApps()
                    .map { it.activityInfo.packageName }
                    .filter { it != packageName && it !in allowedPackages }
                    .distinct()
                if (disallowed.isNotEmpty()) {
                    dpm.setPackagesSuspended(admin, disallowed.toTypedArray(), true)
                }
                val previouslySuspended = prefs.getStringSet("suspended_packages", emptySet()) ?: emptySet()
                val toResume = previouslySuspended - disallowed.toSet()
                if (toResume.isNotEmpty()) {
                    dpm.setPackagesSuspended(admin, toResume.toTypedArray(), false)
                }
                prefs.edit().putStringSet("suspended_packages", disallowed.toSet()).apply()
            } else if (Build.VERSION.SDK_INT >= 24) {
                val previouslySuspended = prefs.getStringSet("suspended_packages", emptySet()) ?: emptySet()
                if (previouslySuspended.isNotEmpty()) {
                    dpm.setPackagesSuspended(admin, previouslySuspended.toTypedArray(), false)
                    prefs.edit().remove("suspended_packages").apply()
                }
            }

            if (Build.VERSION.SDK_INT >= 23 && !isInLockTaskModeCompat()) {
                startLockTask()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Kiosk policy could not be applied: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun isInLockTaskModeCompat(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return if (Build.VERSION.SDK_INT >= 23) dpm.isLockTaskPermitted(packageName) && (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).lockTaskModeState != android.app.ActivityManager.LOCK_TASK_MODE_NONE else false
    }

    private fun addCoin() {
        if (remoteLocked) { Toast.makeText(this, "CLIENT IS REMOTELY LOCKED", Toast.LENGTH_SHORT).show(); return }
        coins++
        secondsLeft += minutesPerPeso * 60L
        updateScreen()
        startTimer()
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(secondsLeft * 1000L, 1000L) {
            override fun onTick(ms: Long) { secondsLeft = ms / 1000L; updateScreen() }
            override fun onFinish() {
                secondsLeft = 0
                if (autoClearOnExpiry) {
                    clearCustomerSession()
                } else {
                    coins = 0
                }
                closeBrowser()
                updateScreen()
                Toast.makeText(this@MainActivity, "TIME EXPIRED - SESSION CLEARED", Toast.LENGTH_LONG).show()
                // Send the customer back to the Android Home Launcher after expiry.
                goToHomeLauncher()
            }
        }.start()
    }

    private fun clearCustomerSession() {
        coins = 0
        timer?.cancel()
        try { webView.stopLoading() } catch (_: Exception) {}
        try { webView.clearHistory() } catch (_: Exception) {}
        try { webView.clearCache(true) } catch (_: Exception) {}
        try { webView.clearFormData() } catch (_: Exception) {}
        try { webView.clearSslPreferences() } catch (_: Exception) {}
        try { WebStorage.getInstance().deleteAllData() } catch (_: Exception) {}
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().removeSessionCookies(null)
            CookieManager.getInstance().flush()
        } catch (_: Exception) {}
        try { webView.loadUrl("about:blank") } catch (_: Exception) {}
        try { cacheDir.deleteRecursively() } catch (_: Exception) {}
        try { externalCacheDir?.deleteRecursively() } catch (_: Exception) {}
        try { filesDir.resolve("customer_session").deleteRecursively() } catch (_: Exception) {}
        try { getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.deleteRecursively() } catch (_: Exception) {}
        try { getSharedPreferences("customer_browser_session", MODE_PRIVATE).edit().clear().apply() } catch (_: Exception) {}
    }

    private fun updateScreen() {
        val h = secondsLeft / 3600
        val m = (secondsLeft % 3600) / 60
        val s = secondsLeft % 60
        val value = String.format("%02d:%02d:%02d", h, m, s)
        txtTime.text = value
        txtBrowserTime.text = value
        txtCoins.text = "Coins: $coins"
        txtRate.text = "₱1 = $minutesPerPeso minutes"
    }

    private fun connectEsp32() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: run { Toast.makeText(this, "Bluetooth not supported", Toast.LENGTH_SHORT).show(); return }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) { requestBtPermission(); return }
        val target = btTargetName.trim()
        val devices = adapter.bondedDevices.filter { (it.name ?: "").contains(target, true) }
        if (devices.isEmpty()) { Toast.makeText(this, "Pair $target in Android Bluetooth settings first.", Toast.LENGTH_LONG).show(); return }
        connectDevice(devices.first())
    }

    private fun connectDevice(device: BluetoothDevice) {
        txtEsp32.text = "ESP32: CONNECTING..."
        thread {
            try {
                socket?.close()
                socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket!!.connect()
                runOnUiThread { txtEsp32.text = "ESP32: CONNECTED" }
                listenBluetooth(socket!!)
            } catch (_: Exception) {
                runOnUiThread { txtEsp32.text = "ESP32: NOT CONNECTED"; if (bluetoothAlarm) Toast.makeText(this, "BLUETOOTH DISCONNECTED", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun listenBluetooth(s: BluetoothSocket) {
        try {
            val reader = BufferedReader(InputStreamReader(s.inputStream))
            while (s.isConnected) {
                val line = reader.readLine() ?: break
                if (line.trim().equals("COIN1", true)) runOnUiThread { addCoin() }
            }
        } catch (_: Exception) {
            runOnUiThread { txtEsp32.text = "ESP32: NOT CONNECTED"; if (bluetoothAlarm) Toast.makeText(this, "BLUETOOTH DISCONNECTED", Toast.LENGTH_LONG).show() }
        }
    }

    private fun showPasswordDialog() {
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; hint = "Admin password" }
        AlertDialog.Builder(this).setTitle("ADMIN / STAFF LOGIN").setMessage("Enter Admin Password or Staff PIN").setView(input).setNegativeButton("CANCEL", null).setPositiveButton("OK") { _, _ ->
            val value = input.text.toString()
            if (value == adminPassword || value == staffPassword) showSettingsDialog(value == adminPassword)
            else Toast.makeText(this, "Incorrect Admin / Staff password!", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun showSettingsDialog(isAdmin: Boolean) {
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 8, 28, 8)
        }

        fun addToggle(label: String, checked: Boolean, enabled: Boolean = true): CheckBox =
            CheckBox(this).also {
                it.text = label
                it.isChecked = checked
                it.isEnabled = enabled
                menu.addView(it)
            }

        val clientHeader = TextView(this).apply {
            text = "CLIENT CONFIGURATION"
            textSize = 16f
            setPadding(0, 8, 0, 4)
        }
        menu.addView(clientHeader)

        val clientNameInput = EditText(this).apply {
            hint = "Client Name"
            setText(clientName)
            isEnabled = isAdmin
        }
        menu.addView(clientNameInput)

        val clientIdInput = EditText(this).apply {
            hint = "Client ID"
            setText(clientId)
            isEnabled = isAdmin
        }
        menu.addView(clientIdInput)

        val deviceOwnerStatus = TextView(this).apply {
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            text = if (dpm.isDeviceOwnerApp(packageName)) {
                "Device Owner: ACTIVE"
            } else {
                "Device Owner: NOT PROVISIONED"
            }
            setPadding(0, 6, 0, 10)
        }
        menu.addView(deviceOwnerStatus)

        val coinMinutes = EditText(this).apply {
            hint = "Minutes per ₱1"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(minutesPerPeso.toString())
        }
        menu.addView(coinMinutes)

        val password = EditText(this).apply {
            hint = if (isAdmin) "New Admin Password" else "New Staff PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        menu.addView(password)

        val kiosk = addToggle("Kiosk Mode", kioskMode, isAdmin)
        val launcher = addToggle("Default Launcher", defaultLauncher, isAdmin)
        val btAlarm = addToggle("Bluetooth Disconnect Alarm", bluetoothAlarm, isAdmin)
        val chAlarm = addToggle("Charger Disconnect Alarm", chargerAlarm, isAdmin)
        val whitelist = addToggle("Whitelist Apps", whitelistMode, isAdmin)
        val autoClear = addToggle("Auto-clear customer session when timer expires", autoClearOnExpiry, isAdmin)

        val remoteToggle = addToggle("Remote Management", remoteControlEnabled, isAdmin)

        val remoteUrlInput = EditText(this).apply {
            hint = "Remote Control HTTPS URL (use {clientId})"
            setText(remoteControlUrl)
            isEnabled = isAdmin
        }
        menu.addView(remoteUrlInput)

        val remoteIntervalInput = EditText(this).apply {
            hint = "Remote Poll Seconds (10-300)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(remotePollSeconds.toString())
            isEnabled = isAdmin
        }
        menu.addView(remoteIntervalInput)

        val target = EditText(this).apply {
            hint = "Bluetooth Target Name"
            setText(btTargetName)
        }
        menu.addView(target)

        if (isAdmin) {
            menu.addView(Button(this).apply {
                text = "MANAGE ALLOWED APPS"
                setOnClickListener { showAllowedAppsDialog() }
            })
            menu.addView(Button(this).apply {
                text = "CLEAR REMOTE LOCK (LOCAL ADMIN)"
                setOnClickListener {
                    remoteLocked = false
                    remoteLockMessage = "This client is temporarily disabled by the administrator."
                    applyRemoteLockUi()
                    Toast.makeText(this@MainActivity, "Local remote lock cleared", Toast.LENGTH_SHORT).show()
                }
            })
        }

        // Keep the settings content scrollable while keeping SAVE/CANCEL
        // permanently visible at the bottom of the dialog.
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(menu)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 0, 20, 8)
            addView(scroll, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            ))
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }

        val cancelButton = Button(this).apply {
            text = "CANCEL"
            setOnClickListener { dialogRef?.dismiss() }
        }
        val saveButton = Button(this).apply {
            text = "SAVE"
            isAllCaps = true
        }

        buttons.addView(cancelButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        buttons.addView(saveButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        root.addView(buttons, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (isAdmin) "KIOSK & LAUNCHER CONTROL" else "COIN TIMER SETTINGS")
            .setMessage("Coin Timer / Device Settings")
            .setView(root)
            .create()

        dialogRef = dialog

        saveButton.setOnClickListener {
            val n = coinMinutes.text.toString().toIntOrNull()
            if (n == null || n <= 0) {
                coinMinutes.error = "Enter a number greater than 0"
                coinMinutes.requestFocus()
                return@setOnClickListener
            }

            minutesPerPeso = n
            if (isAdmin) {
                clientName = clientNameInput.text.toString().trim().ifEmpty { "Client 01" }
                clientId = clientIdInput.text.toString().trim().ifEmpty { "C001" }
            }
            val newPassword = password.text.toString().trim()
            if (newPassword.isNotEmpty()) {
                if (isAdmin) adminPassword = newPassword else staffPassword = newPassword
            }

            if (isAdmin) {
                kioskMode = kiosk.isChecked
                defaultLauncher = launcher.isChecked
                bluetoothAlarm = btAlarm.isChecked
                chargerAlarm = chAlarm.isChecked
                whitelistMode = whitelist.isChecked
                autoClearOnExpiry = autoClear.isChecked
                remoteControlEnabled = remoteToggle.isChecked
                remoteControlUrl = remoteUrlInput.text.toString().trim()
                remotePollSeconds = (remoteIntervalInput.text.toString().toIntOrNull() ?: 15).coerceIn(10, 300)
            }

            btTargetName = target.text.toString().trim().ifEmpty { "ESP32" }
            updateScreen()
            applyKioskMode()
            applyRemoteLockUi()
            startRemoteControl()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            dialogRef = null

            if (isAdmin && launcher.isChecked) {
                requestHomeLauncherRole()
            }
        }

        cancelButton.setOnClickListener {
            dialog.dismiss()
            dialogRef = null
        }

        dialog.setOnDismissListener { dialogRef = null }
        dialog.show()

        // Give the dialog a usable tablet width and ensure the custom button
        // row remains visible instead of being pushed below the screen.
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.90f).toInt(),
            (resources.displayMetrics.heightPixels * 0.88f).toInt()
        )
    }


    private fun getLaunchableApps(): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    private fun showCustomerAppsDialog() {
        if (remoteLocked) { Toast.makeText(this, "CLIENT IS REMOTELY LOCKED", Toast.LENGTH_SHORT).show(); return }
        if (secondsLeft <= 0L) {
            Toast.makeText(this, "Insert a coin first", Toast.LENGTH_SHORT).show()
            return
        }
        val allowed = getLaunchableApps().filter { it.activityInfo.packageName in allowedPackages }
        if (allowed.isEmpty()) {
            Toast.makeText(this, "No allowed apps configured", Toast.LENGTH_SHORT).show()
            return
        }
        val names = allowed.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("ALLOWED APPS")
            .setItems(names) { _, which ->
                try {
                    val pkg = allowed[which].activityInfo.packageName
                    val launch = packageManager.getLaunchIntentForPackage(pkg)
                    if (launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(launch)
                    }
                } catch (_: Exception) {
                    Toast.makeText(this, "App could not be opened", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun showAllowedAppsDialog() {
        val apps = getLaunchableApps()
        if (apps.isEmpty()) {
            Toast.makeText(this, "No launchable apps found", Toast.LENGTH_SHORT).show()
            return
        }
        val names = apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        val packages = apps.map { it.activityInfo.packageName }
        val selected = allowedPackages.toMutableSet()
        val checked = BooleanArray(apps.size) { packages[it] in selected }

        AlertDialog.Builder(this)
            .setTitle("ALLOWED APPS")
            .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                if (isChecked) selected.add(packages[which]) else selected.remove(packages[which])
            }
            .setMessage("Only selected apps are allowed in PisoTab's launcher list. PisoTab itself is always allowed.")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("SAVE") { _, _ ->
                allowedPackages = selected
                applyKioskMode()
                Toast.makeText(this, "Allowed apps saved: ${selected.size}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun applyRemoteLockUi() {
        remoteLockOverlay.visibility = if (remoteLocked) View.VISIBLE else View.GONE
        txtRemoteLockMessage.text = remoteLockMessage
        txtRemoteLockClient.text = "Client: $clientId — $clientName"
        mainPanel.isEnabled = !remoteLocked
        browserPanel.isEnabled = !remoteLocked
        if (remoteLocked) {
            timer?.cancel()
            secondsLeft = 0L
            coins = 0
            browserPanel.visibility = View.GONE
            mainPanel.visibility = View.VISIBLE
            clearCustomerSession()
        }
    }

    private fun startRemoteControl() {
        remoteRunning = false
        remoteThread?.interrupt()
        if (!remoteControlEnabled || remoteControlUrl.isBlank()) return
        remoteRunning = true
        remoteThread = thread(isDaemon = true, name = "PisoTabRemoteControl") {
            while (remoteRunning) {
                pollRemoteCommand()
                try { Thread.sleep(remotePollSeconds.coerceIn(10, 300) * 1000L) } catch (_: InterruptedException) { break }
            }
        }
    }

    private fun pollRemoteCommand() {
        var conn: HttpURLConnection? = null
        try {
            val base = remoteControlUrl
            val separator = if (base.contains("?")) "&" else "?"
            val urlString = base.replace("{clientId}", Uri.encode(clientId)) +
                if (base.contains("{clientId}")) "" else "${separator}clientId=${Uri.encode(clientId)}&clientName=${Uri.encode(clientName)}"
            conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-PisoTab-Client-Id", clientId)
            }
            if (conn.responseCode in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val locked = json.optBoolean("locked", remoteLocked)
                val message = json.optString("message", remoteLockMessage)
                runOnUiThread {
                    remoteLockMessage = message
                    if (locked != remoteLocked) {
                        remoteLocked = locked
                        applyRemoteLockUi()
                        Toast.makeText(this, if (locked) "REMOTE LOCK ENABLED" else "REMOTE UNLOCK ENABLED", Toast.LENGTH_LONG).show()
                    } else {
                        applyRemoteLockUi()
                    }
                }
            }
        } catch (_: Exception) {
            // Fail closed: retain the last known lock state when the server is unreachable.
        } finally {
            conn?.disconnect()
        }
    }

    override fun onBackPressed() {
        if (browserPanel.visibility == View.VISIBLE) {
            if (webView.canGoBack()) webView.goBack() else closeBrowser()
        } else if (!kioskMode) {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        remoteRunning = false
        remoteThread?.interrupt()
        timer?.cancel()
        try { socket?.close() } catch (_: Exception) {}
        try { webView.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }
}
