package com.example.pisotab

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.CountDownTimer
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var txtTime: TextView
    private lateinit var txtCoins: TextView
    private var coins = 0
    private var secondsLeft = 0L
    private var timer: CountDownTimer? = null

    private val prefs by lazy { getSharedPreferences("pisotab_settings", MODE_PRIVATE) }

    private var minutesPerPeso: Int
        get() = prefs.getInt("minutes_per_peso", 10)
        set(value) = prefs.edit().putInt("minutes_per_peso", value).apply()

    private var adminPassword: String
        get() = prefs.getString("admin_password", "1234") ?: "1234"
        set(value) = prefs.edit().putString("admin_password", value).apply()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtTime = findViewById(R.id.txtTime)
        txtCoins = findViewById(R.id.txtCoins)

        findViewById<Button>(R.id.btnTestCoin).setOnClickListener {
            addCoin()
        }

        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            showPasswordDialog()
        }

        updateScreen()
    }

    private fun addCoin() {
        coins++
        secondsLeft += minutesPerPeso * 60L
        txtCoins.text = "Coins: $coins"
        startTimer()
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(secondsLeft * 1000L, 1000L) {
            override fun onTick(ms: Long) {
                secondsLeft = ms / 1000L
                updateScreen()
            }

            override fun onFinish() {
                secondsLeft = 0
                updateScreen()
                Toast.makeText(
                    this@MainActivity,
                    "TIME EXPIRED",
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }

    private fun updateScreen() {
        val h = secondsLeft / 3600
        val m = (secondsLeft % 3600) / 60
        val s = secondsLeft % 60
        txtTime.text = String.format("%02d:%02d:%02d", h, m, s)
        txtCoins.text = "Coins: $coins"
    }

    private fun showPasswordDialog() {
        val input = EditText(this).apply {
            hint = "Admin password"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 8, 48, 0)
            addView(input)
        }

        AlertDialog.Builder(this)
            .setTitle("Admin Settings")
            .setMessage("Enter password")
            .setView(box)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("OK") { _, _ ->
                if (input.text.toString() == adminPassword) {
                    showSettingsDialog()
                } else {
                    Toast.makeText(this, "Wrong password", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showSettingsDialog() {
        val minutesInput = EditText(this).apply {
            hint = "Minutes per ₱1"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(minutesPerPeso.toString())
        }

        val passwordInput = EditText(this).apply {
            hint = "New admin password"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setText(adminPassword)
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 8, 48, 0)
            addView(minutesInput)
            addView(passwordInput)
        }

        AlertDialog.Builder(this)
            .setTitle("PisoTab Settings")
            .setMessage("Change the ₱1 time and admin password.")
            .setView(box)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("SAVE") { _, _ ->
                val newMinutes = minutesInput.text.toString().toIntOrNull()
                val newPassword = passwordInput.text.toString()

                if (newMinutes == null || newMinutes <= 0) {
                    Toast.makeText(this, "Minutes must be greater than 0", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (newPassword.isBlank()) {
                    Toast.makeText(this, "Password cannot be empty", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                minutesPerPeso = newMinutes
                adminPassword = newPassword

                Toast.makeText(
                    this,
                    "Saved: ₱1 = $newMinutes minutes",
                    Toast.LENGTH_LONG
                ).show()
            }
            .show()
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
