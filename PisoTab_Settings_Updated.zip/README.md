# PisoTab Free Starter

Basic Android starter for a Piso Tab-style timer.

Current features:
- ₱1 test coin button
- Configurable `minutesPerPeso` in MainActivity
- Countdown timer
- Coin counter
- Full-screen landscape activity

Next modules to add:
1. Password-protected settings
2. Kiosk / dedicated-device mode
3. Whitelisted apps
4. ESP32/Bluetooth coin input
5. Charger/Bluetooth disconnect alarms
6. Persistent timer/database

IMPORTANT:
This is a starter project, not the proprietary JTech Support PisoTab V3 APK.
Do not copy proprietary code or branding. This project is an independent implementation.


Updated: password-protected Settings and configurable minutes per peso. Default password: 1234.
