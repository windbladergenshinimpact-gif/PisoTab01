package com.example.pisotab

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.app.AlertDialog
import android.app.DownloadManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebStorage
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var txtTime: TextView
    private lateinit var txtCoins: TextView
    private lateinit var txtEsp32: TextView
    private lateinit var txtRate: TextView
    private lateinit var browserPanel: LinearLayout
    private lateinit var mainPanel: LinearLayout
    private lateinit var webView: WebView
    private lateinit var txtBrowserTime: TextView
    private var coins = 0
    private var secondsLeft = 0L
    private var timer: CountDownTimer? = null
    private var socket: BluetoothSocket? = null

    private val prefs by lazy { getSharedPreferences("pisotab_settings", MODE_PRIVATE) }
    private var minutesPerPeso: Int
        get() = prefs.getInt("minutes_per_peso", 5)
        set(v) = prefs.edit().putInt("minutes_per_peso", v).apply()
    private var adminPassword: String
        get() = prefs.getString("admin_password", "1234") ?: "1234"
        set(v) = prefs.edit().putString("admin_password", v).apply()
    private var staffPassword: String
        get() = prefs.getString("staff_password", "1234") ?: "1234"
        set(v) = prefs.edit().putString("staff_password", v).apply()
    private var kioskMode: Boolean
        get() = prefs.getBoolean("kiosk_mode", true)
        set(v) = prefs.edit().putBoolean("kiosk_mode", v).apply()
    private var defaultLauncher: Boolean
        get() = prefs.getBoolean("default_launcher", false)
        set(v) = prefs.edit().putBoolean("default_launcher", v).apply()
    private var bluetoothAlarm: Boolean
        get() = prefs.getBoolean("bt_alarm", false)
        set(v) = prefs.edit().putBoolean("bt_alarm", v).apply()
    private var chargerAlarm: Boolean
        get() = prefs.getBoolean("charger_alarm", false)
        set(v) = prefs.edit().putBoolean("charger_alarm", v).apply()
    private var whitelistMode: Boolean
        get() = prefs.getBoolean("whitelist_mode", false)
        set(v) = prefs.edit().putBoolean("whitelist_mode", v).apply()
    private var btTargetName: String
        get() = prefs.getString("bt_target_name", "ESP32") ?: "ESP32"
        set(v) = prefs.edit().putString("bt_target_name", v).apply()
    private var autoClearOnExpiry: Boolean
        get() = prefs.getBoolean("auto_clear_on_expiry", true)
        set(v) = prefs.edit().putBoolean("auto_clear_on_expiry", v).apply()

    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        txtTime = findViewById(R.id.txtTime)
        txtCoins = findViewById(R.id.txtCoins)
        txtEsp32 = findViewById(R.id.txtEsp32)
        txtRate = findViewById(R.id.txtRate)
        mainPanel = findViewById(R.id.mainPanel)
        browserPanel = findViewById(R.id.browserPanel)
        webView = findViewById(R.id.webView)
        txtBrowserTime = findViewById(R.id.txtBrowserTime)

        findViewById<Button>(R.id.btnTestCoin).setOnClickListener { addCoin() }
        findViewById<Button>(R.id.btnBrowser).setOnClickListener { openBrowser() }
        findViewById<Button>(R.id.btnConnect).setOnClickListener { connectEsp32() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showPasswordDialog() }
        findViewById<Button>(R.id.btnBrowserHome).setOnClickListener { webView.loadUrl("file:///android_asset/home.html") }
        findViewById<Button>(R.id.btnBrowserBack).setOnClickListener { if (webView.canGoBack()) webView.goBack() else closeBrowser() }
        findViewById<Button>(R.id.btnHomeLauncher).setOnClickListener { goToHomeLauncher() }

        setupBrowser()
        updateScreen()
        requestBtPermission()
        applyKioskMode()
    }

    private fun setupBrowser() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            saveFormData = false
            setSupportMultipleWindows(false)
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            allowContentAccess = true
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val name = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType)
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .setTitle(name)
                    .setDescription("PisoTab customer download")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                    .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
                val cookies = CookieManager.getInstance().getCookie(url)
                if (!cookies.isNullOrBlank()) request.addRequestHeader("Cookie", cookies)
                request.addRequestHeader("User-Agent", userAgent)
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun openBrowser() {
        if (secondsLeft <= 0L) {
            Toast.makeText(this, "Insert a coin first", Toast.LENGTH_SHORT).show()
            return
        }
        mainPanel.visibility = View.GONE
        browserPanel.visibility = View.VISIBLE
        if (webView.url.isNullOrBlank() || webView.url == "about:blank") webView.loadUrl("file:///android_asset/home.html")
        applyKioskMode()
    }

    private fun goToHomeLauncher() {
        // Return to the Android Home/Launcher. If PisoTab is configured as the
        // default launcher, Android will return to PisoTab itself.
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addCategory(Intent.CATEGORY_DEFAULT)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(homeIntent)
        } catch (_: Exception) {
            closeBrowser()
        }
    }

    private fun closeBrowser() {
        browserPanel.visibility = View.GONE
        mainPanel.visibility = View.VISIBLE
    }

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 22)
        }
    }

    private fun applyKioskMode() {
        if (!kioskMode) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            return
        }
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        // Full Android Lock Task is available only after this app is provisioned
        // as Device Owner. Otherwise we keep the safe immersive kiosk UI.
        try {
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(this, PisoTabDeviceAdminReceiver::class.java)
            if (dpm.isDeviceOwnerApp(packageName)) {
                dpm.setLockTaskPackages(admin, arrayOf(packageName))
                if (Build.VERSION.SDK_INT >= 28) {
                    dpm.setLockTaskFeatures(admin, 0)
                }
                if (Build.VERSION.SDK_INT >= 23 && !isInLockTaskModeCompat()) startLockTask()
            }
        } catch (_: Exception) { }
    }

    private fun isInLockTaskModeCompat(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return if (Build.VERSION.SDK_INT >= 23) dpm.isLockTaskPermitted(packageName) && (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).lockTaskModeState != android.app.ActivityManager.LOCK_TASK_MODE_NONE else false
    }

    private fun addCoin() {
        coins++
        secondsLeft += minutesPerPeso * 60L
        updateScreen()
        startTimer()
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(secondsLeft * 1000L, 1000L) {
            override fun onTick(ms: Long) { secondsLeft = ms / 1000L; updateScreen() }
            override fun onFinish() {
                secondsLeft = 0
                if (autoClearOnExpiry) {
                    clearCustomerSession()
                } else {
                    coins = 0
                }
                closeBrowser()
                updateScreen()
                Toast.makeText(this@MainActivity, "TIME EXPIRED - SESSION CLEARED", Toast.LENGTH_LONG).show()
                // Send the customer back to the Android Home Launcher after expiry.
                goToHomeLauncher()
            }
        }.start()
    }

    private fun clearCustomerSession() {
        coins = 0
        timer?.cancel()
        try { webView.stopLoading() } catch (_: Exception) {}
        try { webView.clearHistory() } catch (_: Exception) {}
        try { webView.clearCache(true) } catch (_: Exception) {}
        try { webView.clearFormData() } catch (_: Exception) {}
        try { webView.clearSslPreferences() } catch (_: Exception) {}
        try { WebStorage.getInstance().deleteAllData() } catch (_: Exception) {}
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().removeSessionCookies(null)
            CookieManager.getInstance().flush()
        } catch (_: Exception) {}
        try { webView.loadUrl("about:blank") } catch (_: Exception) {}
        try { cacheDir.deleteRecursively() } catch (_: Exception) {}
        try { externalCacheDir?.deleteRecursively() } catch (_: Exception) {}
        try { filesDir.resolve("customer_session").deleteRecursively() } catch (_: Exception) {}
        try { getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.deleteRecursively() } catch (_: Exception) {}
        try { getSharedPreferences("customer_browser_session", MODE_PRIVATE).edit().clear().apply() } catch (_: Exception) {}
    }

    private fun updateScreen() {
        val h = secondsLeft / 3600
        val m = (secondsLeft % 3600) / 60
        val s = secondsLeft % 60
        val value = String.format("%02d:%02d:%02d", h, m, s)
        txtTime.text = value
        txtBrowserTime.text = value
        txtCoins.text = "Coins: $coins"
        txtRate.text = "₱1 = $minutesPerPeso minutes"
    }

    private fun connectEsp32() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: run { Toast.makeText(this, "Bluetooth not supported", Toast.LENGTH_SHORT).show(); return }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) { requestBtPermission(); return }
        val target = btTargetName.trim()
        val devices = adapter.bondedDevices.filter { (it.name ?: "").contains(target, true) }
        if (devices.isEmpty()) { Toast.makeText(this, "Pair $target in Android Bluetooth settings first.", Toast.LENGTH_LONG).show(); return }
        connectDevice(devices.first())
    }

    private fun connectDevice(device: BluetoothDevice) {
        txtEsp32.text = "ESP32: CONNECTING..."
        thread {
            try {
                socket?.close()
                socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket!!.connect()
                runOnUiThread { txtEsp32.text = "ESP32: CONNECTED" }
                listenBluetooth(socket!!)
            } catch (_: Exception) {
                runOnUiThread { txtEsp32.text = "ESP32: NOT CONNECTED"; if (bluetoothAlarm) Toast.makeText(this, "BLUETOOTH DISCONNECTED", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun listenBluetooth(s: BluetoothSocket) {
        try {
            val reader = BufferedReader(InputStreamReader(s.inputStream))
            while (s.isConnected) {
                val line = reader.readLine() ?: break
                if (line.trim().equals("COIN1", true)) runOnUiThread { addCoin() }
            }
        } catch (_: Exception) {
            runOnUiThread { txtEsp32.text = "ESP32: NOT CONNECTED"; if (bluetoothAlarm) Toast.makeText(this, "BLUETOOTH DISCONNECTED", Toast.LENGTH_LONG).show() }
        }
    }

    private fun showPasswordDialog() {
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; hint = "Admin password" }
        AlertDialog.Builder(this).setTitle("ADMIN / STAFF LOGIN").setMessage("Enter Admin Password or Staff PIN").setView(input).setNegativeButton("CANCEL", null).setPositiveButton("OK") { _, _ ->
            val value = input.text.toString()
            if (value == adminPassword || value == staffPassword) showSettingsDialog(value == adminPassword)
            else Toast.makeText(this, "Incorrect Admin / Staff password!", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun showSettingsDialog(isAdmin: Boolean) {
        val menu = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 8, 28, 0) }
        fun addToggle(label: String, checked: Boolean, enabled: Boolean = true): CheckBox = CheckBox(this).also { it.text = label; it.isChecked = checked; it.isEnabled = enabled; menu.addView(it) }
        val coinMinutes = EditText(this).apply { hint = "Minutes per ₱1"; inputType = InputType.TYPE_CLASS_NUMBER; setText(minutesPerPeso.toString()) }
        menu.addView(coinMinutes)
        val password = EditText(this).apply { hint = if (isAdmin) "New Admin Password" else "New Staff PIN"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        menu.addView(password)
        val kiosk = addToggle("Kiosk Mode", kioskMode, isAdmin)
        val launcher = addToggle("Default Launcher", defaultLauncher, isAdmin)
        val btAlarm = addToggle("Bluetooth Disconnect Alarm", bluetoothAlarm, isAdmin)
        val chAlarm = addToggle("Charger Disconnect Alarm", chargerAlarm, isAdmin)
        val whitelist = addToggle("Whitelist Apps", whitelistMode, isAdmin)
        val autoClear = addToggle("Auto-clear customer session when timer expires", autoClearOnExpiry, isAdmin)
        val target = EditText(this).apply { hint = "Bluetooth Target Name"; setText(btTargetName) }
        menu.addView(target)
        if (isAdmin) menu.addView(Button(this).apply { text = "ADD WHITELIST APP"; setOnClickListener { Toast.makeText(this@MainActivity, "Whitelist app selection will be added with device-owner setup.", Toast.LENGTH_SHORT).show() } })
        AlertDialog.Builder(this).setTitle(if (isAdmin) "KIOSK & LAUNCHER CONTROL" else "COIN TIMER SETTINGS").setMessage("Coin Timer / Device Settings").setView(menu).setNegativeButton("CANCEL", null).setPositiveButton("SAVE") { _, _ ->
            val n = coinMinutes.text.toString().toIntOrNull()
            if (n == null || n <= 0) { Toast.makeText(this, "Minutes must be greater than 0", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
            minutesPerPeso = n
            val newPassword = password.text.toString().trim()
            if (newPassword.isNotEmpty()) { if (isAdmin) adminPassword = newPassword else staffPassword = newPassword }
            if (isAdmin) { kioskMode = kiosk.isChecked; defaultLauncher = launcher.isChecked; bluetoothAlarm = btAlarm.isChecked; chargerAlarm = chAlarm.isChecked; whitelistMode = whitelist.isChecked; autoClearOnExpiry = autoClear.isChecked }
            btTargetName = target.text.toString().trim().ifEmpty { "ESP32" }
            updateScreen(); applyKioskMode(); Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        }.show()
    }

    override fun onBackPressed() {
        if (browserPanel.visibility == View.VISIBLE) {
            if (webView.canGoBack()) webView.goBack() else closeBrowser()
        } else if (!kioskMode) {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        timer?.cancel()
        try { socket?.close() } catch (_: Exception) {}
        try { webView.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }
}
